﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.Entity;
using BusTicketBookingMVCApp.Models;
namespace BusTicketBookingMVCApp.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult About()
        {
            return View();
        }

        public ActionResult Services()
        {
            return View();
        }

        public ActionResult Gallery()
        {
            return View();

        }

        public ActionResult Bus()
        {
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Registration()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Booking()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Registration(TblRegister tblRegister)
        {
            using(TicketDataEntities db=new TicketDataEntities())
            {
                if(ModelState.IsValid)
                {
                    db.TblRegisters.Add(tblRegister);
                    db.SaveChanges();
                    ViewBag.message("Registartion Sucessfuly");
                    ModelState.Clear();
                    //insert Data from database table
                }
            }
            return View(tblRegister);
        }
        [HttpPost]
        public ActionResult Login(TblRegister tblRegister)
        {
            using (TicketDataEntities db = new TicketDataEntities())
            {
                if (ModelState.IsValid)
                {
                    var obj = db.TblRegisters.Where(a => a.userName.Equals(tblRegister.userName) && a.pass.Equals(tblRegister.pass)).FirstOrDefault();
                    if (obj != null)
                    {
                        //Session["UserID"] = obj.UserId.ToString();
                        //Session["UserName"] = obj.email.ToString();
                        return RedirectToAction("Order");
                    }
                    ViewBag.message("Login Sucessfuly");
                    ModelState.Clear();
                    //insert Data from database table
                }
            }
            
            return View(tblRegister);
        }
        [HttpPost]
        public ActionResult Booking(TicketBooking ticketBooking)
        {
            using (TicketDataEntities db = new TicketDataEntities())
            {
                if (ModelState.IsValid)
                {
                    db.TicketBookings.Add(ticketBooking);
                    db.SaveChanges();
                    ViewBag.message("Ticket Confirm plese wait SMS");
                    ModelState.Clear();
                    //insert Data from database table
                }
            }
            
            return View(ticketBooking);
        }
    }
}